package ValidationOfEmailID;

import java.util.Scanner;

public class ValidationOfEmailID {

	public static void main(String[] args) {
        // email IDs entered in the array
        String[] emailList = {
            "akanksha.kirola@gmail.com",
            "nidhi.kirola@gmail.com",
            "tara.kirola@gmail.com",
            "tarun.kirola@gmail.com"
        };

        // Enter the email ID from the user
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter an email ID to be searched: ");
        String searchEmail = scanner.nextLine();

     // here search is performed
        boolean found = false;
        for (String email : emailList) {
            if (email.equalsIgnoreCase(searchEmail)) {
                found = true;
                break;
            }
        }

        // Search result is displayed
        if (found) {
            System.out.println("Email ID found.");
        } else {
            System.out.println("Email ID not found.");
        }
    }
}



