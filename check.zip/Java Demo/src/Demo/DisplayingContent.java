package Demo;

import java.util.Scanner;
public class DisplayingContent {
	public static void main(String[] args) {
	// Here we will do factorial program
	//1!= 1
	//2!= 1*2
		//Declaring Variables
		int n;
		//Scanner object is created	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter a number:");
	n = sc.nextInt();
	
	// For factorial
	//int fact_var = 1;
	//for(int i = 1; i <= n; i++) {
	//fact_var = fact_var * i;
	//}
	int fact_var = 1;
	int i = 1;
	while(i <= n) {
		fact_var *= i;
		i++;
	}
	
	System.out.println("Factorial of the number "+n+" will be:" + (fact_var) );	
		
	}
	 
}
