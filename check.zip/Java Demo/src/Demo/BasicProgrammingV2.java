package Demo;
import java.util.Scanner;
public class BasicProgrammingV2 {
	public static void main (String[] args) {
		int num1, num2;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Type number 1:");
		num1 = sc.nextInt();
		System.out.println("Type number 2:");
		num2 = sc.nextInt();
// The numbers are taken by the user
	System.out.println("Arithmetic operations on both numbers will be:"+(num1+num2));
	System.out.println("Subtraction of the two numbers will be:"+(num1-num2));
	System.out.println("Multiplication of the given numbers will be:"+(num1 * num2));
	System.out.println("Division of the given numbers will be:"+(num1 / num2));
	System.out.println("Modulo of he given numers will be:"+(num1 % num2));
	}
}

