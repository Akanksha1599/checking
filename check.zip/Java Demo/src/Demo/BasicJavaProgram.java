package Demo;

public class BasicJavaProgram {
	public static void main (String[] args) {
		int num1 = 20, num2 = 10;// The numbers here are hardcoded
		System.out.println("Arithmetic operations on both numbers will be:"+(num1+num2));
		System.out.println("Subtraction of the two numbers will be:"+(num1-num2));
		System.out.println("Multiplication of the given numbers will be:"+(num1 * num2));
		System.out.println("Division of the given numbers will be:"+(num1 / num2));
		System.out.println("Modulo of he given numers will be:"+(num1 % num2));
	}
}
