package regrex;

import java.util.regex.*;

public class regrexImplementation {
	    
	public static void main(String args[]){  
		//pattern matcher matches the and checks  if the same pattern is present or not and gives output in true or false
	System.out.println(Pattern.matches("[amn]", "abcd"));  
	System.out.println(Pattern.matches("[amn]", "a"));  
	System.out.println(Pattern.matches("[amn]", "ammmna")); 
	}
}


