package typecasting;

public class typeCasting {
	public static void main(String[] args) {
		int x = 10;
		//implicit type casting done here
		double y = x;
		System.out.println("Implicit typecasting: ");
		System.out.println("Integer value: "+x);
		System.out.println("Double value: "+y);
		
		double m = 20.22;
		//explicit type casting done here
		int n = (int) m;
		System.out.println("Explicit typecasting: ");
		System.out.println("Double value: "+m);
		System.out.println("Integer value: "+n);

		}
	
}