package stringconversion;

public class stringConversion {
	public static void main(String[] args) {
        
        String str = " I am Akanksha.";

        StringBuffer stringBuffer = new StringBuffer(str);
        StringBuilder stringBuilder = new StringBuilder(stringBuffer);

        System.out.println("String: " + str);
        System.out.println("StringBuffer: " + stringBuffer.toString());
        System.out.println("StringBuilder: " + stringBuilder.toString());
    }
}
